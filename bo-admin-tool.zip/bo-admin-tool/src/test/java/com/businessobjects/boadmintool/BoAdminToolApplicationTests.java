package com.businessobjects.boadmintool;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoAdminToolApplicationTests {

	@Test
	void contextLoads() {
	}

}
